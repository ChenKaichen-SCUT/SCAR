import json, sys
from pathlib import Path
root=Path(__file__).resolve().parent
version, destination=sys.argv[1],Path(sys.argv[2])
mapping=json.loads((root/'snapshots'/version/'sources.json').read_text())
for name,digest in mapping.items():
 target=destination/'scar_public'/name; target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes((root/'blobs'/digest).read_bytes())
for origin, relative in ((root/'analysis','scar_public/experiments'),(root/'evidence'/version,'frozen_results'),(root/'diagnostics','diagnostics')):
 for source in origin.rglob('*'):
  if source.is_file():
   target=destination/relative/source.relative_to(origin);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
print('Restored',version,'to',destination)
