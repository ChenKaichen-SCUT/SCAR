Extract this archive, then run: python restore.py development_v1 DESTINATION
Other snapshots: development_v2, holdout. The command restores exact hashed Python sources and frozen_results.
See scar_public/experiments/README_REACHABLE_LABELS.txt for source datasets and run commands.
