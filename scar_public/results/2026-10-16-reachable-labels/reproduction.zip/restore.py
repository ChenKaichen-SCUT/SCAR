import argparse,json,hashlib,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('snapshot');p.add_argument('output',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent;out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
mapping=json.loads((root/'snapshots'/a.snapshot/'files.json').read_text())
for name,h in mapping.items():
 target=(out/name).resolve()
 if not target.is_relative_to(out):raise ValueError('unsafe snapshot path')
 data=(root/'blobs'/h).read_bytes()
 assert hashlib.sha256(data).hexdigest()==h
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
for src in (root/'snapshots'/a.snapshot).iterdir():
 if src.name!='files.json':
  target=out/'frozen_results'/src.name;target.parent.mkdir(exist_ok=True);target.write_bytes(src.read_bytes())
print('Restored',len(mapping),'files to',out)
